Hall Inc Giftbit Server (LIVE)
-----------------------------
This server integrates Hall Inc with Giftbit for live gift deliveries (Visa default).
Important: DO NOT commit your live API key to source control.

Environment variables (set these in Render service settings):
 - GIFTBIT_API_KEY : Your Giftbit live API key (keep secret)
 - SENDER_EMAIL : e.g. mh6ll@themh6llentertainment.store
 - COINS_PER_USD : number (default 100; 100 coins = $1)
 - STARTING_COINS : default starting coins for new users
 - GIFT_EXPIRY : YYYY-MM-DD default expiry date for gifts

Quick endpoints:
 - GET /                 -> health
 - POST /api/register    -> { id?, name?, email } create user with starting coins
 - GET  /api/users       -> list users
 - GET  /api/balance/:userId -> check user coins
 - POST /api/redeem/giftbit -> { userId, coins, recipientEmail? } redeem coins to Giftbit gift (live)
 - GET  /api/payments
 - GET  /api/orders

Deploying on Render:
 - Create a new Web Service (manual deploy or from repo)
 - Ensure env vars are configured in Render (GIFTBIT_API_KEY etc)
 - Start command: node server.js
