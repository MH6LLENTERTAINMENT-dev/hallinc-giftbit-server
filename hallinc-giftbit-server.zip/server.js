// server.js - Hall Inc Giftbit backend (CommonJS)
// LIVE mode ready - reads GIFTBIT_API_KEY from environment variables
// WARNING: Do NOT commit your live API key to source control. Set it in Render environment variables.

const express = require('express');
const fetch = require('node-fetch');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 3001;
const DATA_FILE = path.join(__dirname, 'data.json');
const COINS_PER_USD = Number(process.env.COINS_PER_USD || 100); // 100 coins = $1
const STARTING_COINS = Number(process.env.STARTING_COINS || 2000);

// Giftbit config (set these in Render env)
const GIFTBIT_API_KEY = process.env.GIFTBIT_API_KEY || '';
const SENDER_EMAIL = process.env.SENDER_EMAIL || 'mh6ll@themh6llentertainment.store';
const BRAND_CODE = process.env.BRAND_CODE || 'VISA'; // default reward brand code (change to actual Giftbit brand code)
const GIFT_EXPIRY = process.env.GIFT_EXPIRY || '2026-12-31';

// Simple file DB helpers
function readData(){
  try{
    return JSON.parse(fs.readFileSync(DATA_FILE,'utf8'));
  }catch(e){
    const init = { users: [], orders: [], payments: [] };
    fs.writeFileSync(DATA_FILE, JSON.stringify(init,null,2));
    return init;
  }
}
function writeData(db){
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

// Health
app.get('/', (req, res) => res.send('✅ Hall Inc Giftbit Server (LIVE mode)'));

// Create or list users
app.get('/api/users', (req,res)=>{
  const db = readData();
  res.json({ ok:true, users: db.users });
});

app.post('/api/register', (req,res)=>{
  const { id, name, email } = req.body;
  if(!email) return res.status(400).json({ ok:false, error:'email required' });
  const db = readData();
  const userId = id || `user-${Date.now()}`;
  if(db.users.find(u=>u.id===userId)) return res.status(400).json({ ok:false, error:'user exists' });
  const user = { id: userId, name: name||'User', email, coins: STARTING_COINS, createdAt: Date.now() };
  db.users.unshift(user);
  writeData(db);
  res.json({ ok:true, user });
});

// Get balance
app.get('/api/balance/:userId', (req,res)=>{
  const db = readData();
  const user = db.users.find(u=>u.id===req.params.userId);
  if(!user) return res.status(404).json({ ok:false, error:'user not found' });
  res.json({ ok:true, balance: user.coins });
});

// Redeem coins for Giftbit reward (Visa by default)
// BODY: { userId, coins, recipientEmail (optional) }
app.post('/api/redeem/giftbit', async (req,res)=>{
  try{
    const { userId, coins, recipientEmail } = req.body;
    if(!userId || !coins) return res.status(400).json({ ok:false, error:'userId and coins required' });
    const db = readData();
    const user = db.users.find(u=>u.id===userId);
    if(!user) return res.status(404).json({ ok:false, error:'user not found' });
    if(user.coins < coins) return res.status(400).json({ ok:false, error:'insufficient coins' });
    if(!GIFTBIT_API_KEY) return res.status(500).json({ ok:false, error:'GIFTBIT_API_KEY not configured on server' });

    const coinsNum = Number(coins);
    const amountUSD = Number((coinsNum / COINS_PER_USD).toFixed(2));
    if(amountUSD < 1) return res.status(400).json({ ok:false, error:'minimum redeem amount is $1' });

    // Deduct coins immediately
    user.coins = Math.round((user.coins - coinsNum) * 100) / 100;

    // Create payment record
    const paymentId = `pay-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const payment = { id: paymentId, userId, coins: coinsNum, amountUSD, status:'PENDING', createdAt: Date.now() };
    db.payments = db.payments || [];
    db.payments.unshift(payment);
    writeData(db);

    // Call Giftbit PAPI to create a live gift (POST /papi/v1/gifts)
    const payload = {
      "amount": Math.round(amountUSD*100),
      "sender": {
        "name": "THE M.H6LL ENTERTAINMENT",
        "email": SENDER_EMAIL
      },
      "recipient": {
        "email": recipientEmail || user.email
      },
      "delivery": {
        "method": "EMAIL"
      },
      "meta": {
        "paymentId": paymentId,
        "userId": userId
      },
      "expires_at": GIFT_EXPIRY,
      "type": "gift"
    };

    const resp = await fetch('https://api.giftbit.com/papi/v1/gifts', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GIFTBIT_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const data = await resp.json();

    if(!resp.ok){
      payment.status = 'FAILED';
      payment.error = data;
      user.coins = Math.round((user.coins + coinsNum) * 100) / 100;
      writeData(db);
      return res.status(500).json({ ok:false, error: data });
    }

    payment.status = 'CONFIRMED';
    payment.confirmedAt = Date.now();
    payment.giftbitResponse = data;
    db.orders = db.orders || [];
    db.orders.unshift({ id:`order-${Date.now()}`, userId, paymentId, coinsDeducted: coinsNum, amountUSD, status:'COMPLETED', createdAt: Date.now(), giftbit: data });
    writeData(db);

    return res.json({ ok:true, payment, giftbit: data });
  }catch(err){
    console.error('redeem error', err);
    return res.status(500).json({ ok:false, error: String(err) });
  }
});

// Inspect endpoints
app.get('/api/payments', (req,res)=>{ const db=readData(); res.json({ ok:true, payments: db.payments }); });
app.get('/api/orders', (req,res)=>{ const db=readData(); res.json({ ok:true, orders: db.orders }); });

app.listen(PORT, ()=>console.log(`Hall Inc Giftbit server running on port ${PORT}`));
